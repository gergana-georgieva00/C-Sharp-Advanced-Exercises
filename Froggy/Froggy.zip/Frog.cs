﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Froggy
{
    public class Frog
    {
        public void Jump()
        {

        }
    }
}
