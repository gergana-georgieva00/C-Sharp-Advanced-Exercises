﻿namespace DirectoryTraversal
{
    using System;
    using System.IO;

    public class DirectoryTraversal
    {
        static void Main()
        {
            string path = Console.ReadLine();
            string reportFileName = @"\report.txt";

            string reportContent = TraverseDirectory(path);
            Console.WriteLine(reportContent);

            WriteReportToDesktop(reportContent, reportFileName);
        }

        public static string TraverseDirectory(string inputFolderPath)
        {
            Directory.CreateDirectory(inputFolderPath);
            string[] files = Directory.GetFiles(inputFolderPath);
            return files.ToString();
        }

        public static void WriteReportToDesktop(string textContent, string reportFileName)
        {
        }
    }
}
